package org.ggp.base.util.observer;

public interface Observer
{

	public void observe(Event event);

}
