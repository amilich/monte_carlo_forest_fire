package org.ggp.base.util.observer;

public abstract class Event
{

}
