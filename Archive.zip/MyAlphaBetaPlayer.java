import java.util.List;

import org.ggp.base.player.gamer.exception.GamePreviewException;
import org.ggp.base.player.gamer.statemachine.StateMachineGamer;
import org.ggp.base.util.game.Game;
import org.ggp.base.util.statemachine.MachineState;
import org.ggp.base.util.statemachine.Move;
import org.ggp.base.util.statemachine.Role;
import org.ggp.base.util.statemachine.StateMachine;
import org.ggp.base.util.statemachine.cache.CachedStateMachine;
import org.ggp.base.util.statemachine.exceptions.GoalDefinitionException;
import org.ggp.base.util.statemachine.exceptions.MoveDefinitionException;
import org.ggp.base.util.statemachine.exceptions.TransitionDefinitionException;
import org.ggp.base.util.statemachine.implementation.prover.ProverStateMachine;

public class MyAlphaBetaPlayer extends StateMachineGamer {
	@Override
	public StateMachine getInitialStateMachine() {
		return new CachedStateMachine(new ProverStateMachine());
	}

	@Override
	public void stateMachineMetaGame(long timeout)
			throws TransitionDefinitionException, MoveDefinitionException, GoalDefinitionException {
		// TODO Auto-generated method stub
	}

	/**
	 * Controls printing of debug statements.
	 */
	final boolean DEBUG_EN = false;
	final double MAX_SCORE = 100;
	final double MIN_SCORE = 0;


	/**
	 * Function: stateMachineSelectMove
	 * ----------------------------------
	 * Returns move for the player at a given stage.
	 */
	@Override
	public Move stateMachineSelectMove(long timeout)
			throws TransitionDefinitionException, MoveDefinitionException, GoalDefinitionException {
		if (DEBUG_EN) System.out.println("Selecting move for " + getRole());
		StateMachine machine = getStateMachine();
		MachineState currState = getCurrentState();
		Move action = null;
		try {
			action = bestmove(getRole(), currState, machine);
		} catch(Exception e) {
			System.out.println("Error occurred while finding action: " + e);
			return machine.getLegalMoves(currState, getRole()).get(0);
		}
		if (DEBUG_EN) System.out.println("Selected action (role = " + getRole() + ") = " + action);
		return action;
	}

	/**
	 * Function: bestmove
	 * -------------------
	 * Return best possible move using minimax strategy.
	 */
	private Move bestmove(Role role, MachineState state, StateMachine machine) throws MoveDefinitionException,
	GoalDefinitionException, TransitionDefinitionException {
		if (DEBUG_EN) System.out.println("Calculating best move for " + role.toString());
		List<Move> actions = machine.getLegalMoves(state, role);
		double score = MIN_SCORE;
		Move finalMove = actions.get(0);
		for (Move action : actions) {
			double result = minscore(role, action, state, machine);
			if (score == MAX_SCORE) return action;
			if (result > score) {
				score = result;
				finalMove = action;
			}
		}
		return finalMove;
	}

	/**
	 * Function: opponent
	 * -------------------
	 * Find opponent player. Unused if getLegalJointMoves is called.
	 */
	@SuppressWarnings("unused")
	private Role opponent(Role role, StateMachine machine) {
		List<Role> roles = machine.getRoles();
		for (Role r : roles) {
			if (!r.equals(role)) return r;
		}
		return role; // TODO error
	}

	/**
	 * Function: minscore
	 * -------------------
	 * Recursively determine minimum score that can be achieved from choosing a given move
	 * in a given game state (assuming rational opponent).
	 */
	private double minscore(Role role, Move move, MachineState state, StateMachine machine) throws MoveDefinitionException,
	TransitionDefinitionException, GoalDefinitionException {
		// List<Move> actions = machine.getLegalMoves(state, opp);
		// System.out.println("Minscore, role = " + role + ", opp = " + opp + ", moves = " + actions);
		List<List<Move>> jointActions = machine.getLegalJointMoves(state, role, move);
		double score = MAX_SCORE;
		for (List<Move> jointAction : jointActions) { // Opponent's move
			MachineState nextState = machine.getNextState(state, jointAction);
			double result = maxscore(role, nextState, machine);
			if (result == MIN_SCORE) return result; // TODO not 0?
			if (result < score) {
				score = result;
				if (DEBUG_EN) System.out.println("Low score of " + score + " if we play " + jointAction);
			}
		}
		return score;
	}

	/**
	 * Function: maxscore
	 * -------------------
	 * Determine max score that can be achieved from choosing a given move
	 * in a given game state by maximizing minimum score (minimax).
	 */
	private double maxscore(Role role, MachineState currState, StateMachine machine) throws MoveDefinitionException,
	GoalDefinitionException, TransitionDefinitionException {
		if (machine.isTerminal(currState)) {
			return machine.getGoal(currState, role); // TODO correct value
		}
		List<Move> actions = machine.getLegalMoves(currState, role);
		double score = MIN_SCORE;
		for (Move action : actions) {
			double result = minscore(role, action, currState, machine);
			if (result == MAX_SCORE) return result; // TODO
			if (result > score) score = result;
		}
		return score;
	}

	@Override
	public void stateMachineStop() {
		// TODO Auto-generated method stub

	}

	@Override
	public void stateMachineAbort() {
		// TODO Auto-generated method stub

	}

	@Override
	public void preview(Game g, long timeout) throws GamePreviewException {
		// TODO Auto-generated method stub

	}

	@Override
	public String getName() {
		return "AlphaBetaPlayer";
	}
}
