package org.ggp.base.apps.player.config;

import java.awt.LayoutManager;

import javax.swing.JPanel;

@SuppressWarnings("serial")
public abstract class ConfigPanel extends JPanel
{

	public ConfigPanel(LayoutManager layoutManager)
	{
		super(layoutManager);
	}

}
